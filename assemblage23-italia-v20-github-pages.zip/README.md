# Assemblage 23 Italia

**Portale italiano indipendente su Assemblage 23 · Tom Shear** — versione 20.0

Sito statico: home, 20 sezioni, 100 sottopagine, gallerie live, ascolto Spotify e Qobuz, disclaimer.
Non è il sito ufficiale (<https://www.assemblage23.com>) e non è affiliato ad artista o etichette.

## Struttura
- `site/` — sito pubblicato (`index.html`, `a23-data.js` contenuti, `support.js` e `image-slot.js` motore)
- `.github/workflows/deploy.yml` — pubblicazione su GitHub Pages ad ogni push su `main`

## Pubblicazione
Settings → Pages → Source: GitHub Actions. Indirizzo: https://salvatoresinatra0001-ux.github.io/assemblage23-italia/
Dominio proprio: aggiungere `site/CNAME` e aggiornare `canonical` e `sitemap.xml`.

## Contenuti e diritti
Foto: Wikimedia Commons con licenze libere (autore e licenza indicati in pagina). Copertine: Bandcamp ufficiale, a scopo informativo.
Marchi, copertine e musica appartengono ai rispettivi titolari. Vedi la pagina `#/disclaimer`.

A cura di Salvatore Sinatra · v20.0 · 15 ottobre 2026
