(function(){
const L={
  OFF:'https://www.assemblage23.com',NEWS:'https://www.assemblage23.com/news',SHOWS:'https://www.assemblage23.com/shows',CONTACT:'https://www.assemblage23.com/contact',
  BC:'https://assemblage23.bandcamp.com',SP:'https://open.spotify.com/artist/7pwThElmrxl0pjTwXMojCx',SPN:'https://open.spotify.com/album/1ujia8BjXfOVQrJLtBHdWR',
  AM:'https://music.apple.com/it/search?term=Assemblage%2023',QB:'https://www.qobuz.com/it-it/search?q=Assemblage%2023',
  SHOP:'https://assemblage23.bigcartel.com',IG:'https://www.instagram.com/officialassemblage23/',FB:'https://www.facebook.com/pages/Official-Assemblage-23/138651156153800',
  BSKY:'https://www.assemblage23.com/bluesky',BIT:'https://www.bandsintown.com/a/34185-assemblage-23',MET:'https://www.metropolis-records.com/artist/assemblage-23',
  YTN:'https://www.youtube.com/watch?v=YMbd2fWBZw0&list=PLUJIyWjqg4YqYlaWghpP2-5u0o82Z6kKy',REQ:'https://bandsintown.com/artist-subscribe/34185?play_my_city=true'
};
const p=t=>({t:'p',text:t});
const facts=(h,a)=>({t:'facts',h,items:a.map(([k,v])=>({k,v}))});
const tracks=(h,a)=>({t:'tracks',h,items:a.map((s,i)=>{const[x,d]=s.split('|');return{n:String(i+1).padStart(2,'0'),title:x,dur:d||''}})});
const dates=(h,a)=>({t:'dates',h,items:a.map(([d,city,venue,country,status,url])=>({d,city,venue,country,status:status||'Biglietti',url:url||L.BIT,soldout:status==='Sold out'}))});
const links=(h,a)=>({t:'links',h,items:a.map(([label,url,note])=>({label,url,note:note||''}))});
const list=(h,a)=>({t:'list',h,items:a.map(x=>({x}))});
const news=(h,a)=>({t:'news',h,items:a.map(([date,title,text,url])=>({date,title,text,url:url||L.NEWS}))});
const vids=(h,a)=>({t:'video',h,items:a.map(([id,title,meta])=>({id,title,meta,url:'https://www.youtube.com/watch?v='+id}))});
const rel=(h,a)=>({t:'releases',h,items:a.map(([title,year,meta,route])=>({title,year,meta,href:'#/'+route}))});
const PL=[['Bandcamp',L.BC,'Acquisto · FLAC 24-bit'],['Spotify',L.SP,'Streaming'],['Apple Music',L.AM,'Streaming · Lossless'],['Qobuz',L.QB,'Hi-Res · Download'],['YouTube',L.YTN,'Anteprime Null']];
const studio=[['Contempt','1999','Gashed! / Metropolis','catalogo/contempt'],['Failure','2001','Gashed! / Metropolis','catalogo/failure'],['Defiance','2002','Metropolis','catalogo/defiance'],['Storm','2004','Metropolis','catalogo/storm'],['Meta','2007','Metropolis','catalogo/meta'],['Compass','2009','Metropolis','compass'],['Bruise','2012','Metropolis','bruise'],['Endure','2016','Metropolis','endure'],['Mourn','2020','Metropolis','mourn'],['Null','2025','Metropolis · MET 1430','null']];
const D26=[['20 OTT 2026','Karlsruhe','Die Stadtmitte','DE'],['21 OTT 2026','Oberhausen','Kulttempel','DE'],['22 OTT 2026','Amburgo','Indra Musikclub','DE'],['23 OTT 2026','Jönköping','SekktorF','SE','Sold out'],['24 OTT 2026','Hannover','Subkultur','DE','Sold out']];
const DNEXT=D26.concat([['18 DIC 2026','Los Angeles, CA','Catch One','US','Avvisami'],['06 FEB 2027','Toronto, ON','Ground Control','CA'],['05 GIU 2027','Denver, CO','Ritual Noize Fest · ReelWorks','US']]);
const NULLT=['Believe|4:20','Lunatics|4:34','Gone|4:27','Fuel|3:52','Tolerate|4:25','Normal|4:33','Last|5:01','The Line|3:57','Overthrow|4:44','Waited|4:49'];
const S=[];
const sec=(id,title,kicker,intro,related,lk,subs)=>S.push({id,title,kicker,intro,related,links:lk,subs:subs.map(([sid,t,lead,blocks])=>({id:sid,title:t,lead,blocks:blocks||[]}))});

sec('news','News','Aggiornamenti ufficiali in italiano','Le comunicazioni pubblicate da Tom Shear sul sito ufficiale, riassunte in italiano con data e collegamento diretto alla fonte originale.',['tour','null','video'],[['assemblage23.com/news',L.NEWS,'Fonte primaria'],['Bandsintown',L.BIT,'Date live'],['Instagram',L.IG,'Aggiornamenti rapidi']],[
 ['ultime','Ultime notizie','Le note più recenti dal blog ufficiale: interviste, ritorno in Europa, nuovi remix e prime date 2027.',[news('Ottobre / Settembre 2026',[
  ['07.10.2026','A23 a “Unwritten Rules of the Road”','Tom Shear è stato ospite di Tash Cox nell’ultimo episodio stagionale della serie. La puntata è disponibile su YouTube.'],
  ['20.09.2026','Ritorno in Germania (e Svezia)','Dopo le date sold-out di luglio, quattro nuovi concerti in Germania più uno in Svezia. Hannover e Jönköping risultano già esauriti.'],
  ['20.09.2026','INHALT remixa “Believe”','Per celebrare le date europee esce un remix esclusivo di “Believe” firmato dal produttore di Los Angeles INHALT, su tutte le piattaforme dal 2 ottobre.'],
  ['20.09.2026','Ritorno a Toronto','Prima data 2027 annunciata: Ground Control, Toronto, sabato 6 febbraio.'],
  ['20.09.2026','Remix per Frontal Boundary','Disponibile il remix di Tom Shear di “Alone” dei Frontal Boundary.']])]],
 ['archivio-2026','Archivio 2026','Tutti i post ufficiali da gennaio ad aprile 2026.',[news('Gennaio – Aprile 2026',[
  ['24.04.2026','Ritorno a Madison','Concerto al The Crucible di Madison (WI) il 27 giugno con Brittany Bindrim, Mari Kattman, Sensuous Enemy e Lorelei Dreaming.'],
  ['09.03.2026','A23 e Mari Kattman in Florida','Tampa e Orlando: due delle sole quattro date statunitensi previste per l’anno.'],
  ['21.01.2026','Buon anno (in ritardo)','Ringraziamenti a DJ, recensori e fan per l’accoglienza di “Null”, incluso in numerose classifiche “Best of 2025”.'],
  ['21.01.2026','Merch “Null” di nuovo disponibile','T-shirt e felpe “Null” rifornite nelle taglie S–4XL; ultime unità delle tee limitate “Believe” e “Tolerate”.'],
  ['21.01.2026','Synth of the Week','Su Instagram brevi profili degli strumenti usati per A23, ciascuno con un multisample gratuito programmato da Tom.']])]],
 ['archivio-2025','Archivio 2025','Il ciclo di “Null”: annuncio, singoli, anteprime e mini-tour UK.',[news('Agosto – Novembre 2025',[
  ['11.08.2025','Annunciato “Null”','Album consegnato a Metropolis Records: uscita il 7 novembre, anticipata da due singoli digitali.'],
  ['19.09.2025','Esce “Tolerate”','Primo singolo disponibile su tutte le piattaforme e su Bandcamp.'],
  ['27.09.2025','Teaser di “Believe” e data a Berlino','Primo assaggio del secondo singolo; annunciato il concerto al Frannz Club di Berlino del 24 luglio 2026.'],
  ['04.10.2025','Anteprima di “Believe”','Il secondo singolo esce venerdì 10 ottobre. Remix di “Die Alone” dei Brute Opposition.'],
  ['02.11.2025','Grazie, UK','Bilancio del mini-tour UK/Germania; anteprime di tutte le tracce di “Null” su YouTube; partono le spedizioni dei pre-order.']])]],
 ['uscite','Nuove uscite','Cronologia rapida delle pubblicazioni più recenti, dalla più nuova.',[rel('Uscite recenti',[['Believe (INHALT Remix)','2026','Singolo · 02.10.2026','singoli/null-singoli'],['Null','2025','Album · 07.11.2025','null'],['Believe','2025','Singolo · 10.10.2025','null/singoli'],['Tolerate','2025','Singolo · 19.09.2025','null/singoli']])]],
 ['fonti','Fonti & metodo','Come lavoriamo: ogni notizia di questo sito deriva da fonti ufficiali dell’artista o dell’etichetta.',[p('Le notizie sono tradotte e sintetizzate dal blog ufficiale di Tom Shear. Discografia e tracklist sono verificate su Bandcamp, Spotify e sulle pagine di Metropolis Records; le date live provengono dal calendario ufficiale collegato a Bandsintown. Quando una fonte è secondaria lo indichiamo esplicitamente.'),links('Fonti primarie',[['Blog ufficiale',L.NEWS],['Bandcamp ufficiale',L.BC],['Metropolis Records',L.MET],['Calendario Bandsintown',L.BIT]])]]
]);

sec('tour','Tour & Live','Date confermate · stato al 14.10.2026','Il calendario ufficiale di Assemblage 23 con stato dei biglietti, archivio dei concerti recenti e come richiedere una data in Italia.',['lineup','null','italia'],[['Shows ufficiali',L.SHOWS,'Calendario'],['Bandsintown',L.BIT,'Segui e ricevi avvisi'],['Richiedi una data',L.REQ,'Play my city']],[
 ['prossime','Prossime date','Tutte le date annunciate, dall’Europa di ottobre fino al 2027.',[dates('Calendario',DNEXT)]],
 ['europa-2026','Europa · Ottobre 2026','Cinque date in club tra Germania e Svezia, con Mari Kattman special guest.',[p('Dopo una serie di concerti esauriti in Germania a luglio, Assemblage 23 torna in Europa per cinque serate. Il set porta dal vivo il materiale di “Null” insieme ai classici. Hannover e Jönköping sono già sold-out.'),dates('Date',D26)]],
 ['archivio-2026','Live 2026 · archivio','Le date già suonate nel corso dell’anno.',[dates('Già suonate',[['20 MAR 2026','Tampa, FL','New World Music Hall','US','Concluso'],['21 MAR 2026','Winter Park, FL','Conduit','US','Concluso'],['27 GIU 2026','Madison, WI','The Crucible','US','Concluso'],['24 LUG 2026','Berlino','Frannz Club','DE','Concluso']])]],
 ['uk-2025','UK + Germania · Ottobre 2025','Il mini-tour che ha presentato “Null” in anteprima, con Mari Kattman in apertura.',[dates('Mini-tour 2025',[['15 OTT 2025','Bristol','The Exchange','UK','Concluso'],['16 OTT 2025','Manchester','Rebellion','UK','Concluso'],['17 OTT 2025','Glasgow','Ivory Blacks','UK','Concluso'],['18 OTT 2025','Sheffield','The Corporation','UK','Concluso'],['19 OTT 2025','Londra','The Dome','UK','Concluso'],['20 OTT 2025','Oberhausen','Kulttempel','DE','Concluso']]),p('Booking a cura di Stigmata Productions e Contribe. Paul Seegers ha suonato le tastiere sia per A23 sia per il set di Mari Kattman: due ore sul palco ogni sera per sei giorni.')]],
 ['italia','Richiedi una data in Italia','Al momento non risultano date italiane annunciate. Ecco come far sentire la domanda.',[p('Bandsintown permette di seguire l’artista e di segnalare la propria città con “Request a show”: è il segnale più diretto che booking e promoter consultano. Più richieste arrivano da Milano, Bologna, Roma o Torino, più è probabile una data in Italia.'),links('Azioni',[['Richiedi uno show',L.REQ,'Bandsintown · Play my city'],['Segui A23 su Bandsintown',L.BIT,'Avvisi nuove date'],['Contatti ufficiali',L.CONTACT,'Booking']])]]
]);

sec('biografia','Biografia','1988 → oggi','Dalle registrazioni casalinghe di fine anni Ottanta al decimo album: la storia di Assemblage 23 in cinque capitoli.',['tom-shear','discografia','rarita'],[['Bandcamp · about',L.BC],['Metropolis · artista',L.MET]],[
 ['origini','1988–1998 · Le origini','Un concerto dei Depeche Mode, un DJ d’apertura e un suono da inseguire.',[p('Assemblage 23 nasce ufficialmente nel 1988 a Exton, in Pennsylvania. Durante un concerto dei Depeche Mode, Tom Shear resta colpito dalla musica industrial da ballo proposta dal DJ d’apertura: è il suono che cercava. In precedenza aveva già registrato in casa con il nome Man On A Stage.'),p('Al college collabora con Mike Ukstins e Matt Guenette nel progetto synth-pop Procession, breve ma utile come palestra live. Per anni A23 resta un progetto personale: i brani del periodo confluiranno nel 2007 in “Early, Rare, and Unreleased [1988–1998]”.'),facts('Scheda',[['Fondazione','1988'],['Origine','Exton, Pennsylvania'],['Base attuale','Franklin, Massachusetts'],['Generi','EBM · Futurepop · Synthpop · Electro-industrial']])]],
 ['debutto','1999–2002 · Debutto e Metropolis','Contempt, Failure, Defiance: tre album che definiscono il futurepop americano.',[p('È il progetto parallelo Nerve Filter a far circolare il nome: Shear invia materiale di A23 e Nerve Filter a Peter Stone degli Xorcist. Nel 1999 esce il debutto “Contempt” su Gashed!, seguito nel 2001 da “Failure”.'),p('Il singolo “Disappoint” (ottobre 2001, Accession), legato alla perdita del padre, chiude al n. 42 della classifica DAC dei singoli 2001. Lo stesso anno A23 firma con Metropolis Records, che ristampa i primi due album; Accession pubblica la raccolta di remix “Addendum”. “Defiance” arriva nell’ottobre 2002, anticipato dal singolo “Document”.')]],
 ['storm-meta','2004–2007 · Storm e Meta','La fase delle classifiche: “Ground” e “Binary”.',[p('“Storm” esce nell’ottobre 2004 con i singoli “Let the Wind Erase Me” (agosto) e “Ground” (novembre); quest’ultimo resta otto settimane nella classifica DAC arrivando al n. 2. Nel marzo 2007 il singolo “Binary” debutta al n. 21 della classifica singoli di Billboard e anticipa “Meta” (aprile 2007).')]],
 ['compass-bruise','2009–2012 · Compass e Bruise','Un suono più rifinito e maturo.',[p('Nel 2009 escono “Early, Rare & Unreleased Volume Two”, il concerto al Kinetik Festival di Montréal (maggio), il singolo “Spark” e l’album “Compass”, descritto dall’etichetta come più levigato e maturo. Il 12 giugno 2012 arriva “Bruise”, presentato come l’album più compiuto fino a quel momento.')]],
 ['oggi','2016–oggi · Da Endure a Null','Resistenza, lutto, speranza.',[p('“Endure” (2016) è seguito da un tour statunitense. “Mourn” (11 settembre 2020) nasce tra una fase di depressione e l’inizio della pandemia ed è il primo album non seguito da un tour. Nel 2021 “Failure” torna in edizione 20° anniversario su 2LP e 2CD.'),p('Il 7 novembre 2025 esce “Null”, decimo album in studio, che Shear definisce “un album molto clubby ed energico”. Nel 2026 il progetto torna sui palchi di USA ed Europa.')]]
]);

sec('tom-shear','Tom Shear','Autore · produttore · remixer','L’uomo dietro Assemblage 23: scrive, suona, registra e produce tutto da solo, dal 1988.',['biografia','progetti','video'],[['Instagram ufficiale',L.IG,'Synth of the Week'],['Blog ufficiale',L.NEWS]],[
 ['profilo','Profilo','Un progetto di una sola persona, con testi diretti e personali.',[p('Tom Shear è l’unico membro in studio di Assemblage 23: scrive musica e testi e registra personalmente ogni brano. I testi affrontano apertamente temi difficili come perdita, depressione e resilienza, accanto a un costante filo di speranza.'),facts('In breve',[['Ruolo','Musica, testi, voce, programmazione'],['Alias','Nerve Filter, Surveillance'],['Progetto in duo','Helix, con Mari Kattman'],['Etichette','Metropolis (US), Accession (EU)']])]],
 ['metodo','Metodo di lavoro','Scrittura, produzione e mix in autonomia.',[p('Ogni album di A23 è scritto, eseguito e prodotto da Shear. Il formato live, invece, si allarga a tastiere e batteria: è la formula usata da quando il progetto ha iniziato a suonare dal vivo, nel 1996.')]],
 ['strumenti','Strumenti & synth','“Synth of the Week”: i suoni di A23, con campioni gratuiti.',[p('Sull’Instagram ufficiale Tom pubblica brevi profili degli strumenti usati per A23. Ogni episodio include un suono multicampionato programmato da lui, liberamente utilizzabile nelle proprie produzioni.'),links('Dove trovarli',[['@officialassemblage23',L.IG,'Instagram']])]],
 ['remix','Remix firmati A23','Il lavoro di Tom per altri artisti della scena.',[list('Remix recenti',['Frontal Boundary — “Alone” (2026)','Lost Signal — “Not the End of Me” (2025)','Brute Opposition — “Die Alone” (2025)'])]],
 ['interviste','Interviste','Dove ascoltare Tom raccontarsi.',[vids('Video',[['34GLboTatyc','Unwritten Rules of the Road · con Tash Cox','Ottobre 2026'],['dKmJrrVVE3s','Noisewire · video intervista','Gennaio 2026'],['bvP9IT1StMk','Nightshade TV','Ottobre 2025']]),links('Testo',[['Electricity Club','https://www.electricityclub.co.uk/assemblage-23-interview/','Intervista UK, 2025']])]]
]);

sec('discografia','Discografia','10 album · singoli · raccolte','L’intero catalogo di Assemblage 23 organizzato per formato, con collegamenti alle pagine dedicate e alle piattaforme.',['ascolta','singoli','rarita'],[['Bandcamp',L.BC,'Catalogo completo'],['Spotify',L.SP],['Metropolis',L.MET,'Shop etichetta']],[
 ['album','Album in studio','Dieci album, dal 1999 al 2025.',[rel('Album',studio.slice().reverse())]],
 ['singoli','Singoli & EP','I singoli principali in ordine cronologico.',[facts('Singoli',[['2001','Disappoint'],['2002','Document'],['2004','Let the Wind Erase Me · Ground'],['2007','Binary'],['2009','Spark'],['2025','Tolerate · Believe'],['2026','Believe (INHALT Remix)']])]],
 ['raccolte','Raccolte','Remix, archivio e ristampe.',[rel('Raccolte',[['Addendum','2001','Remix · Accession','rarita/addendum'],['Early, Rare, and Unreleased','2007','1988–1998','rarita/eru-1'],['Early, Rare & Unreleased Vol. 2','2009','Archivio','rarita/eru-2'],['Failure · 20th Anniversary','2021','2LP / 2CD','rarita/failure-20']])]],
 ['deluxe','Edizioni deluxe','Le versioni estese con brani bonus e remix.',[list('Edizioni',['Compass (Deluxe) — 2009','Bruise (Deluxe) — 2012','Endure (Deluxe) — 2016, 2 dischi','Mourn [Deluxe Edition] — 2020, 2CD (esaurito)'])]],
 ['etichette','Etichette & distribuzione','Chi pubblica e distribuisce A23.',[facts('Etichette',[['Gashed!','Primi album'],['Metropolis Records','USA · dal 2001'],['Accession Records','Europa · ristampe del catalogo'],['Audioglobe','Distribuzione UE · Sesto Fiorentino (FI)']])]]
]);

sec('null','Null','Decimo album · 07.11.2025','“Null” è il decimo album di Assemblage 23, pubblicato da Metropolis Records: dieci brani, 44 minuti, pensati per il dancefloor.',['singoli','tour','ascolta'],[['Null su Bandcamp',L.BC+'/album/null'],['Null su Spotify',L.SPN],['Anteprime YouTube',L.YTN]],[
 ['panoramica','Panoramica','Il primo album dai tempi di “Mourn” (2020).',[p('Annunciato l’11 agosto 2025, “Null” è il primo full-length dopo “Mourn”. Shear lo descrive come “un album molto clubby ed energico”, ed è stato per lui un’esperienza più serena da realizzare, senza le circostanze complicate del disco precedente.'),facts('Scheda',[['Uscita','7 novembre 2025'],['Etichetta','Metropolis Records'],['Catalogo','MET 1430 (CD) · MET 1430D (digitale)'],['Durata','10 brani · 44:28'],['Produzione','Tom Shear']])]],
 ['tracklist','Tracklist','Dieci tracce, da “Believe” a “Waited”.',[tracks('Null',NULLT)]],
 ['singoli','Singoli','“Tolerate”, “Believe” e il remix di INHALT.',[facts('Singoli',[['19.09.2025','Tolerate'],['10.10.2025','Believe'],['02.10.2026','Believe (INHALT Remix)']]),p('Su “Believe” Shear spiega che il brano parla di credere nella possibilità di qualcosa di meglio: davanti ai tempi difficili, la cosa più sovversiva può essere avere speranza.')]],
 ['formati','Formati','Digitale, CD e vinile — nessuna edizione speciale.',[facts('Formati',[['Digitale','FLAC 24-bit/44.1kHz · MP3 320'],['CD','Metropolis MET 1430'],['Vinile','LP'],['Edizioni speciali','Nessuna']]),links('Acquista',[['Bandcamp',L.BC+'/album/null','Digitale, CD, vinile'],['Shop ufficiale',L.SHOP,'CD e vinili autografati']])]],
 ['ascolto','Ascolta Null','Ogni piattaforma, un clic.',[links('Piattaforme',[['Bandcamp',L.BC+'/album/null','Acquisto'],['Spotify',L.SPN,'Streaming'],['Apple Music',L.AM,'Streaming'],['Qobuz',L.QB,'Hi-Res'],['Anteprime su YouTube',L.YTN,'Playlist ufficiale']])]]
]);

sec('mourn','Mourn','Nono album · 11.09.2020','“Mourn” è il disco del lutto e dell’ansia: nato tra depressione e pandemia, è il primo album di A23 non seguito da un tour.',['endure','null','biografia'],[['Bandcamp',L.BC],['Metropolis',L.MET]],[
 ['panoramica','Panoramica','Elettronica da ballo e introspezione.',[p('Pubblicato da Metropolis Records l’11 settembre 2020, “Mourn” fonde elettronica danzabile e testi intimi. Molti recensori hanno notato il legame simbolico tra i temi di perdita e la data di uscita.'),facts('Scheda',[['Uscita','11 settembre 2020'],['Etichetta','Metropolis Records'],['Produzione','Tom Shear'],['Formati','Digitale, CD, vinile, 2CD Deluxe']])]],
 ['tracklist','Tracklist','Dieci brani, da “Epiphany” a “This House Is Empty”.',[tracks('Mourn',['Epiphany|6:44','Factory|5:04','Bloom|5:18','Anxiety|4:50','Confession|5:36','Dissonance|5:23','Welcome, Apocalypse|5:12','Could’ve|3:59','Tragedy|5:20','This House Is Empty|4:24'])]],
 ['contesto','Contesto','Un album scritto in un anno difficile.',[p('Il disco è stato influenzato sia dalla depressione vissuta da Shear dopo “Endure”, sia dall’arrivo della pandemia di COVID-19. Per la prima volta in sette album, l’uscita non è stata seguita da un tour.')]],
 ['temi','Temi','Di cosa parla “Mourn”.',[list('Temi ricorrenti',['Lutto e perdita','Ansia e dissonanza interiore','“Factory”: il trauma di chi torna dalla guerra e viene lasciato solo','Fine del mondo e ironia (“Welcome, Apocalypse”)'])]],
 ['deluxe','Deluxe Edition','2CD con brani bonus.',[p('La Deluxe Edition su doppio CD con tracce bonus risulta esaurita su Bandcamp; resta disponibile in digitale.'),links('Dove',[['Bandcamp',L.BC]])]]
]);

sec('endure','Endure','Ottavo album · 2016','Con “Endure” Assemblage 23 consolida il proprio posto nella storia dell’EBM moderna. Nel 2026 il disco compie dieci anni.',['bruise','mourn','tour'],[['Endure su Bandcamp',L.BC+'/album/endure'],['Spotify',L.SP]],[
 ['panoramica','Panoramica','Il ritorno a un suono più duro dopo “Bruise”.',[facts('Scheda',[['Uscita','2016 (Bandcamp: 9 settembre)'],['Etichetta','Metropolis Records'],['Brani','10'],['Produzione','Tom Shear']])]],
 ['tracklist','Tracklist','Da “Endure” a “December”.',[tracks('Endure',['Endure|3:10','Afterglow|4:39','Bravery|5:11','Salt The Earth|4:35','Static|5:03','Call The Dawn|5:33','Butterfly Effect|5:18','Barren|5:01','Grid|4:43','December|5:32'])]],
 ['deluxe','Deluxe Edition','Il secondo disco: inediti e remix.',[tracks('Disco 2',['Afterglow (The Rain Within Remix)|4:22','Bravery (Interface Remix)|6:23','December (Neuroticfish Remix)|5:13','Ignorance|4:34','Salt The Earth (Angeltheory Remix)|4:32','December (Stereospread Remix)|6:24','Bravery (Solitary Experiments Remix)|5:28','Goliath|5:07','Ignorance (Mr. Kitty Remix)|4:22'])]],
 ['tour-2016','Tour 2016','Dal vivo negli Stati Uniti.',[p('Nell’autunno 2016 Assemblage 23 ha portato “Endure” in tour negli Stati Uniti con tastierista e batterista, la formazione live usata dal 1996.')]],
 ['anniversario','10 anni di Endure','9 settembre 2016 → 9 settembre 2026.',[p('L’anniversario cade a pochi giorni dal ritorno di A23 sui palchi europei. Un buon momento per riascoltarlo dall’inizio.'),links('Riascolta',[['Bandcamp',L.BC+'/album/endure'],['Spotify',L.SP]])]]
]);

sec('bruise','Bruise','Settimo album · 12.06.2012','“Bruise” è presentato dall’etichetta come l’album più compiuto di Assemblage 23: calore musicale e oscurità lirica.',['compass','endure','discografia'],[['Bruise su Bandcamp',L.BC+'/album/bruise'],['Spotify',L.SP]],[
 ['panoramica','Panoramica','Il disco più compiuto, secondo Metropolis.',[facts('Scheda',[['Uscita','12 giugno 2012'],['Etichetta','Metropolis Records'],['Brani','10'],['Edizioni','Standard · Deluxe (2CD Limited)']])]],
 ['tracklist','Tracklist','Da “Crosstalk” a “Otherness”.',[tracks('Bruise',['Crosstalk|4:38','The Last Mistake|4:53','Over & Out|4:09','The Noise Inside My Head|4:14','Outsider|5:32','Darkflow|5:33','Automaton|5:01','The Other Side Of The Wall|4:20','Talk Me Down|5:20','Otherness|4:42'])]],
 ['suono','Il suono','Calore e oscurità.',[p('Il contrasto tra il calore musicale e l’oscurità del testo di “The Last Mistake”, insieme ai ritmi percussivi di “The Noise Inside My Head” e “Darkflow”, definisce il carattere dell’album.')]],
 ['deluxe','Deluxe','L’edizione estesa.',[p('Disponibile in digitale come “Bruise (Deluxe)” su Bandcamp e Spotify; esiste anche un’edizione limitata su doppio CD.'),links('Ascolta',[['Bruise (Deluxe) · Bandcamp',L.BC]])]],
 ['ascolto','Ascolta Bruise','Piattaforme ufficiali.',[links('Piattaforme',PL.slice(0,4))]]
]);

sec('compass','Compass','Sesto album · 2009','Costruito sul successo di “Meta”, “Compass” mostra un suono più levigato: beat solidi, melodie e testi carichi di significato.',['bruise','catalogo','singoli'],[['Compass su Bandcamp',L.BC+'/album/compass'],['Spotify',L.SP]],[
 ['panoramica','Panoramica','Dall’apertura di “Smoke” alla chiusura di “The Cruelest Year”.',[facts('Scheda',[['Uscita','2009 (Bandcamp: 1 ottobre)'],['Etichetta','Metropolis Records'],['Brani','10'],['Singolo','Spark']])]],
 ['tracklist','Tracklist','Dieci brani.',[tracks('Compass',['Smoke|5:19','Collapse|5:31','Impermanence|4:36','How Can You Sleep?|5:33','Spark|4:39','Leave This All Behind|4:17','Alive|5:46','Greed|5:53','Angels & Demons|4:53','The Cruelest Year|4:47'])]],
 ['spark','Spark','Il singolo diventato classico.',[p('Pubblicato nel settembre 2009, “Spark” è diventato uno dei brani più amati dai fan e una presenza fissa nei live.')]],
 ['kinetik','Kinetik 2009','Montréal, maggio 2009.',[p('Pochi mesi prima di “Compass”, A23 suona al Kinetik Festival di Montréal, uno degli eventi di riferimento della scena elettronica industriale nordamericana.')]],
 ['deluxe','Compass (Deluxe)','Versione estesa.',[links('Ascolta',[['Compass (Deluxe) · Bandcamp',L.BC],['Spotify',L.SP]])]]
]);

sec('catalogo','Catalogo storico','1999–2007','I primi cinque album: dal debutto su Gashed! all’era Metropolis, fino a “Meta”.',['biografia','discografia','rarita'],[['Metropolis · catalogo',L.MET],['Bandcamp',L.BC]],[
 ['contempt','Contempt (1999)','Il debutto.',[p('Primo album, pubblicato su Gashed! nel 1999 e ristampato da Metropolis nel novembre 2001. Ha portato A23 in prima linea nella scena electro-industrial e futurepop di fine millennio.'),facts('Scheda',[['Anno','1999'],['Etichetta','Gashed! · ristampa Metropolis']])]],
 ['failure','Failure (2001)','Il disco della svolta.',[p('Secondo album, con il singolo “Disappoint”. Nel 2021 è tornato in edizione 20° anniversario.'),facts('Scheda',[['Anno','2001'],['Singolo','Disappoint'],['Ristampa','20th Anniversary · 2021']])]],
 ['defiance','Defiance (2002)','Ottobre 2002, anticipato da “Document”.',[p('Melodie riconoscibili, ritmi incalzanti e testi molto personali: un seguito naturale di “Failure”. Pubblicato da Metropolis e Accession.')]],
 ['storm','Storm (2004)','Ottobre 2004.',[p('Il quarto album, con i singoli “Let the Wind Erase Me” e “Ground”, quest’ultimo al n. 2 della classifica DAC.')]],
 ['meta','Meta (2007)','Aprile 2007.',[p('Anticipato dal singolo “Binary”, entrato al n. 21 della classifica singoli di Billboard.')]]
]);

sec('singoli','Singoli & Remix','Singoli · remix di e per A23','I singoli che hanno segnato la carriera di A23, i remix firmati da Tom per altri e quelli che la scena ha dedicato a lui.',['discografia','null','tom-shear'],[['Bandcamp',L.BC],['Spotify',L.SP]],[
 ['anni-2000','Singoli 2001–2004','Disappoint, Document, Let the Wind Erase Me, Ground.',[facts('Singoli',[['Ott 2001','Disappoint · n. 42 DAC 2001'],['Set 2002','Document'],['Ago 2004','Let the Wind Erase Me'],['Nov 2004','Ground · n. 2 DAC']])]],
 ['binary-spark','Binary & Spark','2007 e 2009.',[facts('Singoli',[['Mar 2007','Binary · n. 21 Billboard'],['Set 2009','Spark']])]],
 ['null-singoli','Singoli di Null','Tolerate, Believe e il remix INHALT.',[facts('Singoli',[['19.09.2025','Tolerate'],['10.10.2025','Believe'],['02.10.2026','Believe (INHALT Remix) · di Matia Simovich']])]],
 ['remix-di-a23','Remix di Tom Shear','Per altri artisti.',[list('Remix',['Frontal Boundary — “Alone”','Lost Signal — “Not the End of Me”','Brute Opposition — “Die Alone”'])]],
 ['remix-per-a23','Remix per A23','Chi ha reinterpretato Assemblage 23.',[list('Remixer (Endure Deluxe, Null)',['The Rain Within','Interface','Neuroticfish','Angeltheory','Stereospread','Solitary Experiments','Mr. Kitty','INHALT'])]]
]);

sec('rarita','Rarità & Archivio','Demo · raccolte · anniversari','Dieci anni di registrazioni prima del debutto, raccolte di remix e ristampe celebrative.',['biografia','catalogo','discografia'],[['Bandcamp',L.BC]],[
 ['eru-1','Early, Rare, and Unreleased','14 brani dal 1988 al 1998 · pubblicato il 10.04.2007.',[tracks('Tracklist',['Live Intro ’96 (1996)|1:22','Mortuary (1988)|3:26','Anger (1992)|3:36','Chemical Restraint (1992)|8:16','Straightjacket (1988)|4:14','Ambush (1994)|3:44','Soma (1992)|3:33','The Angels Died (1994)|2:45','Sometimes I Wish I Was Dead (1988)|4:12','Underneath the Ice (1995)|4:54','My Burden (1997)|2:33','The Fissure King (1996)|4:08','Void (1998)|4:37','Requiem (1995)|2:10']),links('Ascolta',[['Bandcamp',L.BC+'/album/early-rare-and-unreleased-1988-1998']])]],
 ['eru-2','Early, Rare & Unreleased Vol. 2','Il secondo volume d’archivio (2009).',[p('Pubblicato nel 2009, prosegue lo scavo nel materiale inedito e raro del progetto. Disponibile su Bandcamp.'),links('Ascolta',[['Bandcamp',L.BC]])]],
 ['addendum','Addendum (2001)','La raccolta di remix.',[p('Uscita nel novembre 2001 solo su Accession, raccoglie remix del periodo “Failure”.')]],
 ['failure-20','Failure · 20th Anniversary','2LP e 2CD, 2021.',[p('L’edizione per il ventesimo anniversario di “Failure” è uscita nel 2021 su doppio vinile e doppio CD; il CD è disponibile anche tramite Metropolis.'),links('Dove',[['Bandcamp',L.BC],['Metropolis',L.MET]])]],
 ['pre-a23','Prima di A23','Man On A Stage e Procession.',[list('Progetti',['Man On A Stage — registrazioni casalinghe di fine anni ’80, inizialmente strumentali','Procession — synth-pop al college con Mike Ukstins e Matt Guenette'])]]
]);

sec('ascolta','Ascolta','Bandcamp · Spotify · Apple Music · Qobuz · YouTube','Dove ascoltare e acquistare Assemblage 23, piattaforma per piattaforma, con indicazioni su qualità audio e formati.',['discografia','null','shop'],PL.map(x=>x),[
 ['bandcamp','Bandcamp','Il modo migliore per sostenere direttamente l’artista.',[p('Su Bandcamp si trova l’intero catalogo, con download in MP3, FLAC e altri formati, disponibili in 24-bit/44.1kHz, oltre allo streaming illimitato nell’app per chi acquista.'),links('Apri',[['assemblage23.bandcamp.com',L.BC]])]],
 ['spotify','Spotify','Lo streaming linkato dal sito ufficiale.',[links('Apri',[['Profilo artista',L.SP],['Null',L.SPN,'Album 2025']])]],
 ['apple-music','Apple Music','Streaming con catalogo completo.',[links('Apri',[['Cerca Assemblage 23',L.AM]])]],
 ['qobuz','Qobuz','Per chi ascolta in alta qualità.',[p('Qobuz offre streaming e download in qualità CD e Hi-Res dove disponibile: ideale per apprezzare le produzioni a 24 bit di “Null”.'),links('Apri',[['Cerca Assemblage 23',L.QB]])]],
 ['youtube','YouTube','Anteprime e interviste.',[links('Apri',[['Anteprime di Null',L.YTN,'Playlist ufficiale']])]]
]);

sec('video','Video','Interviste · anteprime · tour','I video ufficiali condivisi da Tom Shear: interviste, anteprime dei singoli e materiale dal tour.',['tom-shear','null','news'],[['Anteprime Null',L.YTN],['Instagram',L.IG]],[
 ['interviste','Interviste video','Tre conversazioni recenti.',[vids('Interviste',[['34GLboTatyc','Unwritten Rules of the Road','Ottobre 2026'],['dKmJrrVVE3s','Noisewire','Gennaio 2026'],['bvP9IT1StMk','Nightshade TV','Ottobre 2025']])]],
 ['anteprime','Anteprime singoli','Tolerate e Believe.',[vids('Anteprime',[['kkoykOA0Dt4','Tolerate · anteprima','Settembre 2025'],['VXFdwepnqZo','Believe · teaser','Settembre 2025'],['vXD3XwxCBjI','Believe · anteprima','Ottobre 2025']])]],
 ['playlist','Playlist Null','Le anteprime di tutti i brani.',[links('Playlist',[['Null · anteprime traccia per traccia',L.YTN,'YouTube']])]],
 ['tour-diary','Tour Diary','Dal canale dell’etichetta.',[links('Video',[['Assemblage 23 Tour Diary #1',L.MET,'Metropolis Records']])]],
 ['canali','Canali ufficiali','Dove escono i nuovi video.',[links('Canali',[['Instagram',L.IG],['Facebook',L.FB],['Bluesky',L.BSKY]])]]
]);

sec('progetti','Progetti paralleli','Helix · Nerve Filter · Surveillance','Oltre Assemblage 23: i progetti, gli alias e le collaborazioni di Tom Shear.',['tom-shear','lineup','biografia'],[['Mari Kattman · Bandcamp','https://marikattman.bandcamp.com']],[
 ['helix','Helix','Il duo con Mari Kattman.',[p('Helix è la collaborazione tra Tom Shear e la vocalist Mari Kattman. Il debutto “Twin” è uscito nel 2016 e il primo concerto si è tenuto al Surly Wench di Tucson, in Arizona. Nel 2021 è stato annunciato l’EP “Bad Dream”.'),facts('Scheda',[['Debutto','Twin · 2016'],['Primo live','Surly Wench, Tucson'],['EP','Bad Dream']])]],
 ['nerve-filter','Nerve Filter','L’alias che aprì la strada.',[p('Progetto parallelo di Shear: proprio le demo di Nerve Filter, inviate insieme a quelle di A23, contribuirono a far conoscere il suo lavoro.')]],
 ['surveillance','Surveillance','Un altro alias di Tom Shear.',[p('Surveillance è uno degli alias ufficiali di Shear, accanto a Nerve Filter, citato tra i progetti collaterali ancora associati ad Assemblage 23.')]],
 ['mari-kattman','Mari Kattman','Special guest nei tour 2025–2026.',[p('Vocalist e produttrice, moglie di Tom e sua partner in Helix. Ha aperto le date UK 2025 e accompagna A23 in tutte le date europee di ottobre 2026; è attiva anche nel mastering per artisti industrial, EBM e synthpop.'),links('Ascolta',[['Mari Kattman · Bandcamp','https://marikattman.bandcamp.com']])]],
 ['altri','Altri progetti','Ed Flesh, Thy Fearful Symmetry, collaborazioni.',[list('Progetti e collaborazioni',['Ed Flesh','Thy Fearful Symmetry','Chiasm — EP “Cut Right Through” feat. Assemblage 23'])]]
]);

sec('lineup','Line-up live','Tastiere · batteria · voce','Assemblage 23 in studio è una persona sola; sul palco diventa un trio.',['tour','tom-shear','progetti'],[['Bandsintown',L.BIT]],[
 ['tom','Tom Shear','Voce e programmazione.',[p('Fondatore e unico autore del progetto, sul palco è alla voce e guida la parte elettronica.')]],
 ['paul','Paul Seegers','Tastiere.',[p('Tastierista storico del live di A23. Nel tour UK 2025 ha suonato anche nel set di Mari Kattman.')]],
 ['mike','Mike Jenney','Batteria.',[p('Batterista della formazione live, che dà corpo fisico ai pattern elettronici di Shear.')]],
 ['formato','Il formato live','Dal 1996 a oggi.',[facts('Formazione',[['Dal vivo dal','1996'],['Voce','Tom Shear'],['Tastiere','Paul Seegers'],['Batteria','Mike Jenney']])]],
 ['crew','Dietro le quinte','Chi rende possibile un tour.',[p('Nei ringraziamenti del tour 2025 Tom cita Stigmata Productions e Contribe per il booking, l’autista Scott, lo staff del Kulttempel di Oberhausen e i fan che hanno dato una mano al banco merch.')]]
]);

sec('shop','Shop & Merch','CD · vinili · abbigliamento','Dove acquistare dischi e merchandising ufficiale, con le note utili per chi ordina dall’Italia.',['ascolta','null','italia'],[['Shop ufficiale',L.SHOP,'Big Cartel'],['Bandcamp',L.BC],['Metropolis',L.MET]],[
 ['ufficiale','Shop ufficiale','CD e vinili autografati, t-shirt, felpe.',[links('Apri',[['assemblage23.bigcartel.com',L.SHOP]])]],
 ['bandcamp','Bandcamp','Digitale e supporti fisici.',[links('Apri',[['assemblage23.bandcamp.com',L.BC,'FLAC 24-bit · CD · vinile']])]],
 ['merch-null','Merch di Null','T-shirt, felpe e tee limitate.',[p('T-shirt e felpe “Null” sono state rifornite in tutte le taglie S–4XL. Le t-shirt “Believe” e “Tolerate” sono in edizione limitata: una volta esaurite non verranno ristampate.')]],
 ['spedizioni','Spedizioni in Europa','Per chi ordina dall’Italia.',[p('Gli articoli autografati destinati all’Europa vengono firmati da Tom e spediti tramite il centro di spedizione tedesco: tempi possibilmente più lunghi rispetto agli ordini USA.')]],
 ['etichetta','Shop dell’etichetta','Metropolis Records.',[links('Apri',[['Metropolis · Assemblage 23',L.MET,'Null CD e vinile']])]]
]);

sec('italia','Community Italia','Per i fan italiani','Lo spazio italiano dedicato ad Assemblage 23: chi siamo, come arriva la musica in Italia e come contribuire.',['tour','contatti','shop'],[['Richiedi una data',L.REQ],['Contatti ufficiali',L.CONTACT]],[
 ['chi-siamo','Chi siamo','Un sito di fan, in italiano.',[p('assemblage23-italia.it è un progetto di fan non ufficiale. Raccogliamo, traduciamo e organizziamo le informazioni pubblicate dai canali ufficiali di Tom Shear, senza sostituirci ad essi: ogni pagina rimanda alla fonte originale.')]],
 ['distribuzione','Distribuzione in Italia','Un pezzo di A23 passa da Firenze.',[p('La distribuzione europea dei titoli Metropolis fa riferimento ad Audioglobe S.r.l. di Sesto Fiorentino (FI): un motivo in più per chiedere i dischi di A23 al proprio negozio di fiducia.')]],
 ['glossario','Glossario dei generi','EBM, futurepop e dintorni, in breve.',[facts('Generi',[['EBM','Electronic Body Music: elettronica ritmica e fisica, nata per il dancefloor'],['Futurepop','Fusione di EBM e melodie synth-pop/trance, esplosa a fine anni ’90'],['Synthpop','Canzone pop costruita su sintetizzatori'],['Electro-industrial','Elettronica più oscura e sperimentale di matrice industrial']])]],
 ['contribuisci','Contribuisci','Correzioni, foto, report.',[list('Puoi inviarci',['Correzioni di date o tracklist con link alla fonte','Foto dei concerti di cui possiedi i diritti','Report dei live per l’archivio italiano'])]],
 ['changelog','Changelog v10.0-pre','Cosa cambia in questa versione.',[list('Novità',['Nuova architettura: 20 sezioni × 5 sottopagine','Collegamenti contestuali in ogni pagina: fonti ufficiali, sezioni correlate, piattaforme','Indice completo navigabile da ogni pagina','Dati verificati su fonti ufficiali al 14.10.2026'])]]
]);

sec('contatti','Contatti & Link','Canali ufficiali verificati','Tutti i collegamenti ufficiali di Assemblage 23 in un unico punto, più FAQ e note legali di questo sito.',['italia','ascolta','news'],[['Sito ufficiale',L.OFF],['Contatti',L.CONTACT]],[
 ['ufficiali','Link ufficiali','Sito, musica, shop.',[links('Ufficiali',[['assemblage23.com',L.OFF],['Bandcamp',L.BC],['Shop',L.SHOP],['Metropolis Records',L.MET]])]],
 ['social','Social','Dove seguire Tom.',[links('Social',[['Instagram',L.IG],['Facebook',L.FB],['Bluesky',L.BSKY],['Bandsintown',L.BIT]])]],
 ['booking','Booking & stampa','Per richieste professionali.',[p('Per booking, interviste e richieste stampa usa esclusivamente il modulo contatti del sito ufficiale.'),links('Contatto',[['assemblage23.com/contact',L.CONTACT]])]],
 ['faq','FAQ','Domande frequenti.',[facts('FAQ',[['Questo è il sito ufficiale?','No: è un sito di fan italiano. Il sito ufficiale è assemblage23.com.'],['Dove compro i dischi?','Bandcamp, lo shop ufficiale o Metropolis Records.'],['Ci sono date in Italia?','Non al momento. Usa “Request a show” su Bandsintown.'],['Quanti album ha pubblicato A23?','Dieci album in studio, l’ultimo è “Null” (2025).']])]],
 ['legale','Note legali','Marchi e contenuti.',[p('Assemblage 23 e tutti i contenuti correlati appartengono ai rispettivi titolari. Questo sito non vende nulla e non riproduce testi o registrazioni: rimanda sempre ai canali ufficiali.')]]
]);

const PH={"news":"Tom Shear — foto stampa recente","tour":"Assemblage 23 live — palco, luci, pubblico","biografia":"Tom Shear — foto d’archivio anni ’90–2000","tom-shear":"Tom Shear — ritratto HD orizzontale","discografia":"I dischi di Assemblage 23 — CD e vinili","null":"Assemblage 23 — servizio fotografico era Null (2025)","mourn":"Tom Shear — foto era Mourn (2020)","endure":"Assemblage 23 live — tour Endure 2016","bruise":"Tom Shear — foto era Bruise (2012)","compass":"Assemblage 23 live — Kinetik 2009","catalogo":"Assemblage 23 — foto storica 1999–2007","singoli":"Tom Shear in studio — produzione e remix","rarita":"Archivio A23 — demo, nastri, primi live","ascolta":"Tom Shear — sessione d’ascolto / cuffie","video":"Assemblage 23 — still da video o intervista","progetti":"Tom Shear & Mari Kattman — Helix","lineup":"Live trio — Shear, Seegers, Jenney","shop":"Merch ufficiale A23 — t-shirt, CD, vinili","italia":"Fan italiani al concerto di Assemblage 23","contatti":"Tom Shear — foto stampa ufficiale"};
S.forEach((s,i)=>{s.n=String(i+1).padStart(2,'0');s.photo={id:'sec-'+s.id,ph:PH[s.id],n:String(i+11).padStart(2,'0')}});
const COVERS={"Null":["https://f4.bcbits.com/img/a1071757081_10.jpg","https://assemblage23.bandcamp.com/album/null"],"Mourn":["https://f4.bcbits.com/img/a0218043235_10.jpg","https://assemblage23.bandcamp.com/album/mourn"],"Endure":["https://f4.bcbits.com/img/a2381236140_10.jpg","https://assemblage23.bandcamp.com/album/endure-deluxe"],"Compass":["https://f4.bcbits.com/img/a3780568629_10.jpg","https://assemblage23.bandcamp.com/album/compass-deluxe"],"Meta":["https://f4.bcbits.com/img/a3464166203_10.jpg","https://assemblage23.bandcamp.com/album/meta"],"Storm":["https://f4.bcbits.com/img/a2571970246_10.jpg","https://assemblage23.bandcamp.com/track/complacent"],"Failure · 20th Anniversary":["https://f4.bcbits.com/img/a0497909042_10.jpg","https://assemblage23.bandcamp.com/album/failure-20th-anniversary-edition"],"Believe (INHALT Remix)":["https://f4.bcbits.com/img/a1621251322_10.jpg","https://assemblage23.bandcamp.com/album/believe-inhalt-remix"]};
S.forEach(s=>{if(COVERS[s.title])s.coverKey=s.title});

const CM='https://commons.wikimedia.org/wiki/',enc=f=>encodeURIComponent(f.replace(/ /g,'_'));
const FP=(f,w)=>CM+'Special:FilePath/'+enc(f)+'?width='+w, PG=f=>CM+'File:'+enc(f);
const LIC={by2:['CC BY 2.0','https://creativecommons.org/licenses/by/2.0/deed.it'],by3:['CC BY 3.0','https://creativecommons.org/licenses/by/3.0/deed.it'],bysa3:['CC BY-SA 3.0','https://creativecommons.org/licenses/by-sa/3.0/deed.it'],att:['Attribuzione (licenza libera)',null]};
const P=(f,a,l,v)=>({f,a,v:!!v,lic:LIC[l][0],lu:LIC[l][1]||PG(f),thumb:FP(f,960),big:FP(f,2560),page:PG(f)});
const pp=n=>'20160305 Oberhausen E-Tropolis Assemblage 23 '+n+'.jpg',cs=n=>'20160305-Assemblage-23-E-tropolis-Oberhausen-'+n+'.jpg',ncn=n=>'Assemblage 23 Nocturnal Culture Night 13 2018 0'+n+'.jpg';
const MF='Markus Felix | PushingPixels';
const GAL=[
{id:'ncn',title:'Nocturnal Culture Night 13',place:'Kulturpark Deutzen (DE)',date:'09.09.2018',era:'Ciclo Endure',ph:[2,5,6,1,7,3,8,4,9].map(n=>P(ncn(n),'S. Bollmann','att',[1,3,4].includes(n)))},
{id:'etropolis',title:'E-tropolis Festival 2016',place:'Turbinenhalle · Oberhausen (DE)',date:'05.03.2016',era:'Anno di Endure',ph:[P(cs(5418),'Carstor','by3'),P(pp('0015'),MF,'bysa3'),P(cs(5371),'Carstor','by3'),P(pp('0026'),MF,'bysa3'),P(cs(5443),'Carstor','by3'),P(pp('0004'),MF,'bysa3',1),P(pp('0033'),MF,'bysa3'),P(cs(5348),'Carstor','by3'),P(pp('0044'),MF,'bysa3'),P(cs(5361),'Carstor','by3'),P(pp('0063'),MF,'bysa3'),P(cs(5362),'Carstor','by3'),P(pp('0067'),MF,'bysa3'),P(cs(5396),'Carstor','by3',1),P(pp('0071'),MF,'bysa3'),P(cs(5368),'Carstor','by3'),P(pp('0126'),MF,'bysa3'),P(cs(5390),'Carstor','by3'),P(pp('0134'),MF,'bysa3'),P(cs(5404),'Carstor','by3'),P(pp('0152'),MF,'bysa3',1),P(cs(5433),'Carstor','by3'),P(pp('0165'),MF,'bysa3'),P(cs(5437),'Carstor','by3'),P(pp('0174'),MF,'bysa3')]},
{id:'amphi',title:'Amphi Festival 2012',place:'Tanzbrunnen · Colonia (DE)',date:'21.07.2012',era:'Anno di Bruise',ph:[['01','7760279620'],['02','7760281442'],['03','7760283984'],['04','7760285430'],['05','7760287286']].map(([n,id])=>P('Assemblage 23 '+n+' ('+id+').jpg','Bobo Boom','by2'))}];
GAL.forEach(g=>g.ph.forEach((p,i)=>{p.gid=g.id;p.i=i}));
const SG={tour:'etropolis',endure:'etropolis',lineup:'etropolis',shop:'etropolis',bruise:'amphi',compass:'amphi',catalogo:'amphi',rarita:'amphi',singoli:'amphi',news:'ncn',null:'ncn',mourn:'ncn',video:'ncn',italia:'ncn',contatti:'ncn'};
window.A23={L,PL,studio,DNEXT,COVERS,GAL,SG,sections:S};
})();
